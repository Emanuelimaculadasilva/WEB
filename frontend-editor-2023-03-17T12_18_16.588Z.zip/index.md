# HTML
Linguagem de marcação de texto

## Hypertext 
Hipertexto -> link / sons / imagens / vídeos

## Markup
Marcação -> tag

## Language
Linguagens -> estrutura semântica / sintaxe

# CSS - Cascading StyleSheet 
Folha de estilo em cascata

##Declarações 

Declarações 
selector -> selector
property -> propriedades
value -> valor
